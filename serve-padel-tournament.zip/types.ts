
export interface Player {
  id: string;
  name: string;
  photoUrl?: string;
  cnic: string; // 13 digits
  pointsScored: number;
}

export interface Team {
  id: string;
  name: string;
  logoUrl?: string;
  players: [Player, Player];
  isHomeTeam: boolean;
  stats: {
    matchesPlayed: number;
    setsWon: number;
    gamesWon: number;
  };
}

export type MatchStatus = 'UPCOMING' | 'LIVE' | 'COMPLETED';

export interface SetScore {
  team1: number;
  team2: number;
}

export interface Match {
  id: string;
  round: 'QUARTERS' | 'SEMIS' | 'FINALS';
  matchNumber: number;
  team1Id?: string;
  team2Id?: string;
  winnerId?: string;
  status: MatchStatus;
  startTime: string;
  court: string;
  sets: SetScore[];
  currentSet: number;
  currentPoints: {
    team1: string; // "0", "15", "30", "40", "AD"
    team2: string;
  };
}

export interface TournamentState {
  teams: Team[];
  matches: Match[];
}
