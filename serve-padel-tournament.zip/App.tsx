
import React, { useState } from 'react';
import { HashRouter, Routes, Route, useNavigate, useParams } from 'react-router-dom';
import { Layout } from './components/Layout';
import { MatchCard } from './components/MatchCard';
import { useTournament } from './hooks/useTournament';
import { AdminPINView } from './components/AdminPINView';
import { WinnerBanner } from './components/WinnerBanner';
import { Trophy, Search, ArrowRight, Camera, User, Hash } from 'lucide-react';
import { Team } from './types';

const Home = () => {
  const { state } = useTournament();
  const liveMatch = state.matches.find(m => m.status === 'LIVE');
  const upcoming = state.matches.filter(m => m.status === 'UPCOMING').slice(0, 3);
  const navigate = useNavigate();

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#C75B3A] to-[#A64B2F] rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
          <Trophy size={140} />
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-4">
            <span className="bg-white/20 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest backdrop-blur-md border border-white/10">
              Serve Padel v1.0
            </span>
            <span className="bg-black/20 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest backdrop-blur-md">
              {state.teams.length}/8 Teams
            </span>
          </div>
          <h2 className="text-4xl font-black font-outfit text-white mb-6 leading-[0.9] uppercase tracking-tighter italic">
            CHAMPIONS<br/>LEAGUE
          </h2>
          <button 
            onClick={() => navigate('/register')}
            className="bg-slate-950 text-[#C75B3A] text-[10px] font-black py-4 px-8 rounded-2xl uppercase tracking-[0.2em] hover:bg-slate-900 transition-all flex items-center gap-2 group/btn shadow-2xl"
          >
            Register Now <ArrowRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
          </button>
        </div>
      </section>

      {/* Live Match */}
      {liveMatch && (
        <section className="relative">
          <div className="flex justify-between items-center mb-4 px-2">
            <h3 className="text-sm font-black font-outfit uppercase italic tracking-tighter text-white flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              Live Now
            </h3>
            <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{liveMatch.court}</span>
          </div>
          <MatchCard 
            match={liveMatch} 
            team1={state.teams.find(t => t.id === liveMatch.team1Id)} 
            team2={state.teams.find(t => t.id === liveMatch.team2Id)} 
          />
        </section>
      )}

      {/* Upcoming Matches */}
      <section>
        <div className="flex justify-between items-end mb-4 px-2">
          <h3 className="text-sm font-black font-outfit uppercase italic tracking-tighter text-white">Upcoming Matches</h3>
          <button onClick={() => navigate('/bracket')} className="text-[10px] font-black text-[#C75B3A] uppercase tracking-widest hover:underline">Bracket View</button>
        </div>
        {upcoming.length > 0 ? (
          upcoming.map(m => (
            <MatchCard 
              key={m.id} 
              match={m} 
              team1={state.teams.find(t => t.id === m.team1Id)} 
              team2={state.teams.find(t => t.id === m.team2Id)} 
            />
          ))
        ) : (
          <div className="bg-slate-900/50 border border-dashed border-slate-800 rounded-[2.5rem] py-16 text-center">
             <Search className="mx-auto text-slate-800 mb-4" size={40} />
             <p className="text-slate-600 font-black uppercase text-[10px] tracking-widest">Awaiting match draw...</p>
          </div>
        )}
      </section>
    </div>
  );
};

const BracketView = () => {
  const { state } = useTournament();
  return (
    <div className="space-y-12 pb-12">
      <header className="mb-8 px-2">
        <h2 className="text-3xl font-black font-outfit text-white uppercase italic tracking-tighter leading-none">Tournament<br/>Bracket</h2>
        <div className="flex gap-4 mt-3">
          <span className="text-slate-500 text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5">
            <div className="w-1 h-1 rounded-full bg-[#C75B3A]" /> 8 Teams
          </span>
          <span className="text-slate-500 text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5">
            <div className="w-1 h-1 rounded-full bg-[#C75B3A]" /> Single Elim
          </span>
        </div>
      </header>

      {['QUARTERS', 'SEMIS', 'FINALS'].map((round) => (
        <section key={round} className="space-y-6">
          <div className="flex items-center gap-4 px-2">
            <h3 className="text-[#C75B3A] font-black uppercase text-[10px] italic tracking-[0.3em]">{round}</h3>
            <div className="h-[1px] flex-1 bg-slate-900" />
          </div>
          {state.matches.filter(m => m.round === round).map(match => (
            <MatchCard 
              key={match.id}
              match={match}
              team1={state.teams.find(t => t.id === match.team1Id)}
              team2={state.teams.find(t => t.id === match.team2Id)}
            />
          ))}
        </section>
      ))}
    </div>
  );
};

const RegistrationView = () => {
  const { registerTeam, state } = useTournament();
  const navigate = useNavigate();
  const [teamName, setTeamName] = useState('');
  const [p1, setP1] = useState({ name: '', cnic: '' });
  const [p2, setP2] = useState({ name: '', cnic: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (state.teams.length >= 8) {
      alert("Tournament is full!");
      return;
    }
    const team: Team = {
      id: `t${Date.now()}`,
      name: teamName,
      players: [
        { id: `p${Date.now()}-1`, name: p1.name, cnic: p1.cnic, pointsScored: 0 },
        { id: `p${Date.now()}-2`, name: p2.name, cnic: p2.cnic, pointsScored: 0 },
      ],
      isHomeTeam: true,
      stats: { matchesPlayed: 0, setsWon: 0, gamesWon: 0 }
    };
    registerTeam(team);
    navigate('/');
  };

  return (
    <div className="pb-12">
      <h2 className="text-3xl font-black font-outfit text-white uppercase italic tracking-tighter mb-8 px-2 leading-none">Register<br/>Your Team</h2>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="space-y-3">
          <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 px-2 flex items-center gap-2">
            <Trophy size={12} className="text-[#C75B3A]" /> Official Team Name
          </label>
          <input 
            required
            value={teamName}
            onChange={e => setTeamName(e.target.value)}
            placeholder="Enter Team Name"
            className="w-full bg-slate-900 border border-slate-800 rounded-3xl py-5 px-8 text-white placeholder-slate-700 focus:outline-none focus:ring-2 focus:ring-[#C75B3A]/50 transition-all text-sm font-bold"
          />
        </div>

        {/* Players Container */}
        <div className="space-y-6">
           {/* Player 1 */}
           <div className="bg-slate-900/50 p-6 rounded-[2.5rem] border border-slate-800 space-y-5 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#C75B3A]/5 rounded-full -mr-8 -mt-8 group-hover:bg-[#C75B3A]/10 transition-all" />
              <div className="flex items-center gap-3 mb-2">
                 <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-[#C75B3A] font-black text-xs">01</div>
                 <h4 className="text-[10px] font-black text-white uppercase tracking-widest">Player One</h4>
              </div>
              
              <div className="space-y-3">
                 <div className="relative">
                    <User size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" />
                    <input required placeholder="Full Name" value={p1.name} onChange={e => setP1({...p1, name: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-3 pl-12 pr-4 text-white text-sm font-bold placeholder-slate-800" />
                 </div>
                 <div className="relative">
                    <Hash size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" />
                    <input required maxLength={13} pattern="\d{13}" placeholder="13-Digit CNIC" value={p1.cnic} onChange={e => setP1({...p1, cnic: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-3 pl-12 pr-4 text-white text-sm font-bold placeholder-slate-800" />
                 </div>
                 <button type="button" className="w-full bg-slate-800/50 py-3 rounded-2xl text-[10px] font-black uppercase text-slate-500 border border-dashed border-slate-700 flex items-center justify-center gap-2">
                   <Camera size={12} /> Upload Photo
                 </button>
              </div>
           </div>

           {/* Player 2 */}
           <div className="bg-slate-900/50 p-6 rounded-[2.5rem] border border-slate-800 space-y-5 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#C75B3A]/5 rounded-full -mr-8 -mt-8 group-hover:bg-[#C75B3A]/10 transition-all" />
              <div className="flex items-center gap-3 mb-2">
                 <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-[#C75B3A] font-black text-xs">02</div>
                 <h4 className="text-[10px] font-black text-white uppercase tracking-widest">Player Two</h4>
              </div>
              
              <div className="space-y-3">
                 <div className="relative">
                    <User size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" />
                    <input required placeholder="Full Name" value={p2.name} onChange={e => setP2({...p2, name: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-3 pl-12 pr-4 text-white text-sm font-bold placeholder-slate-800" />
                 </div>
                 <div className="relative">
                    <Hash size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" />
                    <input required maxLength={13} pattern="\d{13}" placeholder="13-Digit CNIC" value={p2.cnic} onChange={e => setP2({...p2, cnic: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-3 pl-12 pr-4 text-white text-sm font-bold placeholder-slate-800" />
                 </div>
                 <button type="button" className="w-full bg-slate-800/50 py-3 rounded-2xl text-[10px] font-black uppercase text-slate-500 border border-dashed border-slate-700 flex items-center justify-center gap-2">
                   <Camera size={12} /> Upload Photo
                 </button>
              </div>
           </div>
        </div>

        <button 
          type="submit"
          className="w-full bg-[#C75B3A] hover:bg-[#A64B2F] text-white font-black uppercase text-xs tracking-[0.2em] py-6 rounded-3xl shadow-2xl shadow-[#C75B3A]/20 active:scale-95 transition-all"
        >
          Confirm Registration
        </button>
      </form>
    </div>
  );
};

const StatsView = () => {
  const { state } = useTournament();
  const sortedTeams = [...state.teams].sort((a, b) => b.stats.setsWon - a.stats.setsWon || b.stats.gamesWon - a.stats.gamesWon);

  return (
    <div className="pb-12">
      <h2 className="text-3xl font-black font-outfit text-white uppercase italic tracking-tighter mb-8 px-2 leading-none">Tourney<br/>Leaderboard</h2>
      
      <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] overflow-hidden shadow-2xl">
        <table className="w-full text-left">
          <thead className="bg-slate-950">
            <tr>
              <th className="px-6 py-5 text-[9px] font-black uppercase tracking-widest text-slate-600">Pos</th>
              <th className="px-6 py-5 text-[9px] font-black uppercase tracking-widest text-slate-600">Team / Players</th>
              <th className="px-6 py-5 text-[9px] font-black uppercase tracking-widest text-slate-600 text-center">S.Won</th>
              <th className="px-6 py-5 text-[9px] font-black uppercase tracking-widest text-slate-600 text-center">G.Won</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/30">
            {sortedTeams.map((team, idx) => (
              <tr key={team.id} className="group hover:bg-slate-800/20 transition-all">
                <td className="px-6 py-6 font-black italic text-[#C75B3A] text-xl">#{idx + 1}</td>
                <td className="px-6 py-6">
                  <div className="font-black text-white text-sm uppercase italic tracking-tight">{team.name}</div>
                  <div className="text-[9px] text-slate-600 uppercase font-black tracking-widest mt-0.5">{team.players.map(p => p.name.split(' ')[0]).join(' & ')}</div>
                </td>
                <td className="px-6 py-6 text-center font-black text-white">{team.stats.setsWon}</td>
                <td className="px-6 py-6 text-center font-bold text-slate-600">{team.stats.gamesWon}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {sortedTeams.length === 0 && (
          <div className="py-24 text-center">
             <Trophy className="mx-auto text-slate-800 mb-4" size={48} />
             <p className="text-slate-600 font-black uppercase text-[10px] tracking-widest">Awaiting match results...</p>
          </div>
        )}
      </div>
    </div>
  );
};

const MatchScoreView = () => {
  const { id } = useParams();
  const { state, updateMatchScore, setMatchStatus, advanceWinner } = useTournament();
  const [isAdmin, setIsAdmin] = useState(false);
  const [showPin, setShowPin] = useState(false);
  const match = state.matches.find(m => m.id === id);
  const team1 = state.teams.find(t => t.id === match?.team1Id);
  const team2 = state.teams.find(t => t.id === match?.team2Id);
  const navigate = useNavigate();

  if (!match) return null;

  return (
    <div className="pb-12">
      <div className="flex justify-between items-center mb-6 px-2">
        <div />
        {!isAdmin && match.status !== 'COMPLETED' && (
          <button 
            onClick={() => setShowPin(true)}
            className="text-[9px] font-black text-[#C75B3A] bg-[#C75B3A]/10 px-4 py-2 rounded-full uppercase tracking-widest border border-[#C75B3A]/20"
          >
            Referee Entry
          </button>
        )}
      </div>

      {showPin && (
        <AdminPINView onCorrect={() => { setIsAdmin(true); setShowPin(false); }} onCancel={() => setShowPin(false)} />
      )}

      {/* Main Score Display */}
      <div className="bg-slate-900 rounded-[3rem] border border-slate-800 p-8 shadow-[0_20px_50px_rgba(0,0,0,0.5)] relative overflow-hidden mb-10">
        <div className="absolute top-0 left-0 w-full h-[2px] bg-[#C75B3A]" />
        
        <div className="flex flex-col items-center mb-12">
           <span className="text-[10px] font-black text-[#C75B3A] uppercase tracking-[0.3em] mb-3">{match.round} • MATCH {match.matchNumber}</span>
           <div className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border ${match.status === 'LIVE' ? 'bg-red-500/10 text-red-500 border-red-500/20 animate-pulse' : 'bg-slate-800 text-slate-500 border-slate-700'}`}>
              {match.status}
           </div>
        </div>

        <div className="grid grid-cols-[1fr_auto_1fr] gap-6 items-center">
          {/* Team 1 */}
          <div className="flex flex-col items-center gap-5">
            <div className={`w-24 h-24 rounded-[2rem] bg-slate-950 border-2 flex items-center justify-center shadow-2xl transition-all ${match.winnerId === team1?.id ? 'border-[#C75B3A] scale-110' : 'border-slate-800 opacity-60'}`}>
               <span className="text-4xl font-black text-white italic">{team1?.name.charAt(0) || '?'}</span>
            </div>
            <div className="text-center">
              <div className="text-xs font-black uppercase text-white tracking-tight leading-none mb-1">{team1?.name || 'TBD'}</div>
              <div className="text-[8px] text-slate-600 font-black uppercase tracking-widest">{team1?.players[0].name.split(' ')[0]} / {team1?.players[1].name.split(' ')[0]}</div>
            </div>
            {isAdmin && match.status === 'LIVE' && (
              <div className="flex flex-col gap-2 w-full">
                <button 
                  onClick={() => updateMatchScore(match.id, 1, team1?.players[0].id)}
                  className="bg-[#C75B3A] py-2.5 rounded-xl text-white font-black uppercase text-[9px] tracking-widest shadow-lg truncate px-2"
                >
                  {team1?.players[0].name || 'P1'}
                </button>
                <button 
                  onClick={() => updateMatchScore(match.id, 1, team1?.players[1].id)}
                  className="bg-[#C75B3A] py-2.5 rounded-xl text-white font-black uppercase text-[9px] tracking-widest shadow-lg truncate px-2"
                >
                  {team1?.players[1].name || 'P2'}
                </button>
              </div>
            )}
          </div>

          <div className="text-xl font-black text-slate-800 italic">VS</div>

          {/* Team 2 */}
          <div className="flex flex-col items-center gap-5">
            <div className={`w-24 h-24 rounded-[2rem] bg-slate-950 border-2 flex items-center justify-center shadow-2xl transition-all ${match.winnerId === team2?.id ? 'border-[#C75B3A] scale-110' : 'border-slate-800 opacity-60'}`}>
               <span className="text-4xl font-black text-white italic">{team2?.name.charAt(0) || '?'}</span>
            </div>
            <div className="text-center">
              <div className="text-xs font-black uppercase text-white tracking-tight leading-none mb-1">{team2?.name || 'TBD'}</div>
              <div className="text-[8px] text-slate-600 font-black uppercase tracking-widest">{team2?.players[0].name.split(' ')[0]} / {team2?.players[1].name.split(' ')[0]}</div>
            </div>
            {isAdmin && match.status === 'LIVE' && (
              <div className="flex flex-col gap-2 w-full">
                <button 
                  onClick={() => updateMatchScore(match.id, 2, team2?.players[0].id)}
                  className="bg-[#C75B3A] py-2.5 rounded-xl text-white font-black uppercase text-[9px] tracking-widest shadow-lg truncate px-2"
                >
                  {team2?.players[0].name || 'P1'}
                </button>
                <button 
                  onClick={() => updateMatchScore(match.id, 2, team2?.players[1].id)}
                  className="bg-[#C75B3A] py-2.5 rounded-xl text-white font-black uppercase text-[9px] tracking-widest shadow-lg truncate px-2"
                >
                  {team2?.players[1].name || 'P2'}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Current Game Score */}
        <div className="mt-14 flex flex-col items-center gap-2">
           <span className="text-[9px] font-black text-slate-600 uppercase tracking-[0.4em]">Current Game</span>
           <div className="flex items-center gap-10">
              <div className="text-6xl font-black font-outfit italic text-white tracking-tighter">{match.currentPoints.team1}</div>
              <div className="w-[2px] h-8 bg-slate-800 rounded-full" />
              <div className="text-6xl font-black font-outfit italic text-white tracking-tighter">{match.currentPoints.team2}</div>
           </div>
        </div>

        {/* Set Summary */}
        <div className="mt-12 pt-8 border-t border-slate-800 flex justify-center gap-4">
           {match.sets.map((s, i) => (
             <div key={i} className={`flex flex-col items-center min-w-[60px] px-3 py-3 rounded-2xl transition-all border ${match.currentSet === i ? 'bg-slate-950 border-[#C75B3A]/40 ring-1 ring-[#C75B3A]/20' : 'bg-slate-950/50 border-slate-900'}`}>
                <span className="text-[7px] font-black text-slate-700 uppercase mb-2">Set {i+1}</span>
                <div className="flex gap-2 text-base font-black italic">
                   <span className={s.team1 > s.team2 ? 'text-[#C75B3A]' : 'text-slate-500'}>{s.team1}</span>
                   <span className="text-slate-800">-</span>
                   <span className={s.team2 > s.team1 ? 'text-[#C75B3A]' : 'text-slate-500'}>{s.team2}</span>
                </div>
             </div>
           ))}
        </div>
      </div>

      {isAdmin && (
        <div className="space-y-4 px-2">
          {match.status === 'UPCOMING' && (
            <button 
              onClick={() => setMatchStatus(match.id, 'LIVE')}
              className="w-full bg-white text-slate-950 font-black uppercase text-[10px] tracking-[0.2em] py-5 rounded-3xl active:scale-95 transition-all shadow-2xl"
            >
              Start Official Session
            </button>
          )}
          {match.status === 'LIVE' && (
            <div className="grid grid-cols-2 gap-4">
               <button 
                onClick={() => { if(confirm("Confirm Team 1 Win?")) advanceWinner(match.id, team1!.id); }}
                className="bg-slate-900 border border-slate-800 text-slate-400 font-black uppercase text-[9px] py-4 rounded-2xl active:scale-95 transition-all"
              >
                Force Win T1
              </button>
               <button 
                onClick={() => { if(confirm("Confirm Team 2 Win?")) advanceWinner(match.id, team2!.id); }}
                className="bg-slate-900 border border-slate-800 text-slate-400 font-black uppercase text-[9px] py-4 rounded-2xl active:scale-95 transition-all"
              >
                Force Win T2
              </button>
            </div>
          )}
        </div>
      )}

      {match.status === 'COMPLETED' && match.winnerId && (
        <WinnerBanner 
          match={match} 
          winner={state.teams.find(t => t.id === match.winnerId)!} 
          onClose={() => navigate('/')} 
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/bracket" element={<BracketView />} />
          <Route path="/register" element={<RegistrationView />} />
          <Route path="/stats" element={<StatsView />} />
          <Route path="/match/:id" element={<MatchScoreView />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
}
