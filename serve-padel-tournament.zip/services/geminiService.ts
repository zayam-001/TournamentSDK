
import { GoogleGenAI } from "@google/genai";

export async function generateMatchRecap(
  winningTeamName: string,
  players: string[],
  scores: string,
  round: string
) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Write a short, high-energy victory announcement for a padel match. 
      Winner: ${winningTeamName} (Players: ${players.join(", ")})
      Score: ${scores}
      Tournament Round: ${round}
      Include excitement about "Serve Padel" and "Matchup Sports Agency". 
      Keep it under 60 words for a social media banner.`,
    });
    return response.text || "Unbelievable victory! The court was on fire.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return `Incredible performance by ${winningTeamName}! A match to remember at Serve Padel.`;
  }
}
