
import React, { useState } from 'react';
import { ADMIN_PIN } from '../constants';
import { Lock, X } from 'lucide-react';

interface AdminPINViewProps {
  onCorrect: () => void;
  onCancel: () => void;
}

export const AdminPINView: React.FC<AdminPINViewProps> = ({ onCorrect, onCancel }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleInput = (digit: string) => {
    if (pin.length < 4) {
      const newPin = pin + digit;
      setPin(newPin);
      if (newPin.length === 4) {
        if (newPin === ADMIN_PIN) {
          onCorrect();
        } else {
          setError(true);
          setTimeout(() => {
            setPin('');
            setError(false);
          }, 600);
        }
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950/98 backdrop-blur-3xl flex flex-col items-center justify-center p-8">
      <button onClick={onCancel} className="absolute top-12 right-12 text-slate-600 hover:text-white transition-colors">
        <X size={28} />
      </button>

      <div className={`w-20 h-20 bg-slate-900 border-2 rounded-[2rem] flex items-center justify-center mb-10 shadow-2xl transition-all ${error ? 'border-red-500 animate-shake' : 'border-[#C75B3A]/30'}`}>
        <Lock className={`w-8 h-8 ${error ? 'text-red-500' : 'text-[#C75B3A]'}`} />
      </div>

      <h2 className="text-3xl font-black font-outfit text-white uppercase tracking-tighter italic mb-2">RESTRICTED</h2>
      <p className="text-slate-600 text-[10px] font-black uppercase tracking-[0.3em] mb-16">Official Referee Login</p>

      <div className="flex gap-6 mb-20">
        {[0, 1, 2, 3].map(i => (
          <div key={i} className={`w-5 h-5 rounded-full border-2 transition-all duration-300 ${
            pin.length > i ? 'bg-[#C75B3A] border-[#C75B3A] scale-125 shadow-[0_0_15px_rgba(199,91,58,0.5)]' : 'border-slate-800'
          }`} />
        ))}
      </div>

      <div className="grid grid-cols-3 gap-8">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, 'DEL'].map((val, idx) => (
          <button
            key={idx}
            onClick={() => {
              if (val === 'DEL') setPin(prev => prev.slice(0, -1));
              else if (val !== '') handleInput(val.toString());
            }}
            className={`w-16 h-16 rounded-3xl flex items-center justify-center text-xl font-black font-outfit transition-all active:bg-[#C75B3A] active:text-white active:scale-90 ${
              val === '' ? 'pointer-events-none opacity-0' : 'bg-slate-900 border border-slate-800 text-slate-500'
            }`}
          >
            {val}
          </button>
        ))}
      </div>
      
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-10px); }
          75% { transform: translateX(10px); }
        }
        .animate-shake { animation: shake 0.2s ease-in-out infinite; }
      `}</style>
    </div>
  );
};
