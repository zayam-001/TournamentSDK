
import React, { useEffect, useState } from 'react';
import { Team, Match } from '../types';
import { generateMatchRecap } from '../services/geminiService';
import { Share2, Download, Trophy, Sparkles } from 'lucide-react';

interface WinnerBannerProps {
  match: Match;
  winner: Team;
  onClose: () => void;
}

export const WinnerBanner: React.FC<WinnerBannerProps> = ({ match, winner, onClose }) => {
  const [recap, setRecap] = useState("Crafting victory statement...");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRecap = async () => {
      const scoreString = match.sets
        .map(s => `${s.team1}-${s.team2}`)
        .filter(s => s !== "0-0")
        .join(", ");
      const players = winner.players.map(p => p.name);
      const text = await generateMatchRecap(winner.name, players, scoreString, match.round);
      setRecap(text);
      setLoading(false);
    };
    fetchRecap();
  }, [match, winner]);

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950/95 backdrop-blur-2xl flex items-center justify-center p-6">
      <div className="w-full max-w-sm bg-slate-900 border-2 border-[#C75B3A]/40 rounded-[3rem] overflow-hidden shadow-[0_0_80px_rgba(199,91,58,0.25)] relative">
        <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-[#C75B3A] via-white/40 to-[#C75B3A]" />
        
        <div className="p-10 flex flex-col items-center">
          <div className="relative mb-8">
            <div className="w-28 h-28 bg-[#C75B3A] rounded-[2.5rem] flex items-center justify-center shadow-2xl rotate-6 group">
               <Trophy size={56} className="text-white drop-shadow-lg" />
            </div>
            <div className="absolute -top-3 -right-3 bg-white text-slate-950 text-[9px] font-black px-3 py-1.5 rounded-full uppercase tracking-widest shadow-xl flex items-center gap-1">
               <Sparkles size={10} className="text-[#C75B3A]" /> CHAMPIONS
            </div>
          </div>

          <h2 className="text-4xl font-black font-outfit text-white text-center leading-[0.85] uppercase tracking-tighter mb-4 italic">
            MATCH<br/><span className="text-[#C75B3A]">VICTORY</span>
          </h2>
          
          <div className="text-white font-black text-2xl uppercase tracking-tight mb-8 text-center">
            {winner.name}
          </div>

          <div className="w-full bg-slate-950 border border-slate-800 p-6 rounded-[2rem] mb-10">
             <p className={`text-slate-400 text-xs leading-relaxed text-center italic font-bold tracking-tight ${loading ? 'animate-pulse' : ''}`}>
               "{recap}"
             </p>
             <div className="mt-4 flex justify-center gap-2">
                {match.sets.map((s, idx) => (
                   <span key={idx} className="text-[10px] font-black text-slate-700">{s.team1}-{s.team2}</span>
                ))}
             </div>
          </div>

          <div className="flex gap-4 w-full">
            <button 
              onClick={() => alert("Banner exported!")}
              className="flex-1 bg-white text-slate-950 py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all shadow-xl"
            >
              <Download size={14} /> Download
            </button>
            <button 
              onClick={() => alert("Ready to share!")}
              className="flex-1 bg-[#C75B3A] text-white py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all shadow-xl shadow-[#C75B3A]/20"
            >
              <Share2 size={14} /> Share
            </button>
          </div>
          
          <button 
            onClick={onClose}
            className="mt-8 text-slate-600 text-[9px] font-black uppercase tracking-[0.3em] hover:text-white transition-colors"
          >
            Dismiss Gallery
          </button>
        </div>

        <div className="bg-slate-950 py-4 px-10 flex justify-between items-center border-t border-slate-800">
           <span className="text-[9px] font-black text-white italic tracking-tighter">SERVE PADEL</span>
           <span className="text-[9px] font-black text-[#C75B3A] tracking-widest">MATCHUP AGENCY</span>
        </div>
      </div>
    </div>
  );
};
