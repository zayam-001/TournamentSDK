
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Match, Team } from '../types';
import { Clock, MapPin, ChevronRight } from 'lucide-react';

interface MatchCardProps {
  match: Match;
  team1?: Team;
  team2?: Team;
}

export const MatchCard: React.FC<MatchCardProps> = ({ match, team1, team2 }) => {
  const navigate = useNavigate();

  return (
    <div 
      onClick={() => navigate(`/match/${match.id}`)}
      className="bg-slate-900/40 border border-slate-800/80 rounded-[2.5rem] p-6 mb-5 cursor-pointer hover:bg-slate-900 transition-all active:scale-[0.98] group relative overflow-hidden"
    >
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-2">
           <div className="w-1.5 h-1.5 rounded-full bg-[#C75B3A]" />
           <span className="text-[9px] font-black text-slate-500 uppercase tracking-[0.2em]">{match.round} • M{match.matchNumber}</span>
        </div>
        <div className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${
          match.status === 'LIVE' ? 'bg-red-500/10 text-red-500 border border-red-500/10 animate-pulse' :
          match.status === 'COMPLETED' ? 'bg-slate-800 text-slate-600 border border-slate-700/50' :
          'bg-slate-800 text-slate-400 border border-slate-800'
        }`}>
          {match.status}
        </div>
      </div>

      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-4">
        <TeamEntry team={team1} isWinner={match.winnerId === team1?.id} />
        <div className="text-[10px] font-black text-slate-800 italic group-hover:text-[#C75B3A]/30 transition-colors">VS</div>
        <TeamEntry team={team2} isWinner={match.winnerId === team2?.id} align="right" />
      </div>

      <div className="mt-8 pt-5 border-t border-slate-800/50 flex justify-between items-center">
        <div className="flex gap-5">
          <div className="flex items-center gap-2 text-[9px] text-slate-600 font-black uppercase tracking-widest">
            <Clock size={12} className="text-[#C75B3A]/60" />
            {match.startTime}
          </div>
          <div className="flex items-center gap-2 text-[9px] text-slate-600 font-black uppercase tracking-widest">
            <MapPin size={12} className="text-[#C75B3A]/60" />
            {match.court.split(' ')[0]}
          </div>
        </div>
        <div className="p-2 rounded-xl bg-slate-950/50 border border-slate-800 text-slate-700 group-hover:text-white group-hover:bg-[#C75B3A]/20 transition-all">
          <ChevronRight size={14} />
        </div>
      </div>
    </div>
  );
};

const TeamEntry = ({ team, isWinner, align = 'left' }: { team?: Team; isWinner: boolean; align?: 'left' | 'right' }) => (
  <div className={`flex flex-col flex-1 ${align === 'right' ? 'items-end text-right' : 'items-start text-left'}`}>
    <div className={`w-14 h-14 rounded-2xl bg-slate-950 border-2 flex items-center justify-center transition-all ${
      isWinner ? 'border-[#C75B3A] shadow-xl shadow-[#C75B3A]/10 scale-105' : 'border-slate-800'
    }`}>
      {team?.logoUrl ? (
        <img src={team.logoUrl} alt={team.name} className="w-10 h-10 object-contain" />
      ) : (
        <span className="text-xl font-black text-slate-700 italic group-hover:text-slate-400 transition-colors">{team?.name.charAt(0) || '?'}</span>
      )}
    </div>
    <div className="mt-3 w-full">
      <div className={`text-[10px] font-black uppercase tracking-tight truncate ${isWinner ? 'text-[#C75B3A]' : 'text-slate-300'}`}>
        {team?.name || 'Awaiting'}
      </div>
      <div className="text-[7px] font-black text-slate-600 uppercase tracking-widest mt-0.5">
        {team ? `${team.players[0].name.split(' ')[0]} & ${team.players[1].name.split(' ')[0]}` : 'Match TBD'}
      </div>
    </div>
  </div>
);
