
import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { LayoutGrid, Trophy, UserPlus, BarChart3, Radio, ArrowLeft } from 'lucide-react';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const isSubPage = location.pathname !== '/';

  return (
    <div className="min-h-screen flex flex-col max-w-md mx-auto bg-slate-950 shadow-2xl relative overflow-hidden border-x border-slate-900">
      {/* Dynamic Background */}
      <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-[#C75B3A]/10 to-transparent pointer-events-none" />
      <div className="absolute -top-32 -right-32 w-80 h-80 bg-[#C75B3A]/5 rounded-full blur-[100px] pointer-events-none" />
      
      {/* Header */}
      <header className="px-6 pt-10 pb-4 flex justify-between items-center relative z-10">
        <div className="flex items-center gap-3">
          {isSubPage && (
            <button onClick={() => window.history.back()} className="p-2 -ml-2 text-slate-400 hover:text-[#C75B3A] transition-colors">
              <ArrowLeft size={20} />
            </button>
          )}
          <div>
            <h1 className="text-3xl font-black font-outfit italic tracking-tighter text-white leading-none">
              SERVE<span className="text-[#C75B3A]">PADEL</span>
            </h1>
            <p className="text-[10px] uppercase tracking-widest font-black text-slate-500 mt-1">
              Tournament Series
            </p>
          </div>
        </div>
        <div className="h-12 w-12 rounded-2xl bg-slate-900 border border-white/5 flex items-center justify-center shadow-inner">
           <img src="https://api.dicebear.com/7.x/initials/svg?seed=SP&backgroundColor=c75b3a" alt="Serve Logo" className="w-8 h-8 rounded-lg" />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-6 pb-32 overflow-y-auto no-scrollbar relative z-10">
        {children}
      </main>

      {/* Footer Branding */}
      <div className="px-6 pb-28 pt-4 flex justify-center items-center gap-2 opacity-50 relative z-10">
          <div className="h-[1px] w-8 bg-slate-800" />
          <p className="text-[10px] uppercase tracking-tighter font-black text-slate-400">
            Powered by <span className="text-[#C75B3A]">Matchup Sports Agency</span>
          </p>
          <div className="h-[1px] w-8 bg-slate-800" />
      </div>

      {/* Navigation Bar */}
      <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[92%] max-w-[380px] bg-slate-900/90 backdrop-blur-2xl border border-white/10 rounded-[2rem] p-2 flex justify-around items-center shadow-2xl z-50">
        <NavItem to="/" icon={<LayoutGrid size={20} />} label="Home" />
        <NavItem to="/bracket" icon={<Trophy size={20} />} label="Bracket" />
        <NavItem to="/register" icon={<UserPlus size={20} />} label="Join" />
        <NavItem to="/stats" icon={<BarChart3 size={20} />} label="Stats" />
      </nav>
    </div>
  );
};

const NavItem = ({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) => (
  <NavLink
    to={to}
    className={({ isActive }) =>
      `flex flex-col items-center gap-1.5 p-3 rounded-2xl transition-all ${
        isActive ? 'text-[#C75B3A] bg-[#C75B3A]/10' : 'text-slate-500 hover:text-white'
      }`
    }
  >
    {icon}
    <span className="text-[9px] font-black uppercase tracking-widest">{label}</span>
  </NavLink>
);
