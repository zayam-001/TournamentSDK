
import { Match } from './types';

export const ADMIN_PIN = "9292";

export const INITIAL_MATCHES: Match[] = [
  // Quarter Finals
  { id: 'q1', round: 'QUARTERS', matchNumber: 1, status: 'UPCOMING', startTime: 'Sat - 10:00 AM', court: 'Serve Center Court', sets: [{team1:0, team2:0}, {team1:0, team2:0}, {team1:0, team2:0}], currentSet: 0, currentPoints: {team1: "0", team2: "0"} },
  { id: 'q2', round: 'QUARTERS', matchNumber: 2, status: 'UPCOMING', startTime: 'Sat - 11:30 AM', court: 'Serve Center Court', sets: [{team1:0, team2:0}, {team1:0, team2:0}, {team1:0, team2:0}], currentSet: 0, currentPoints: {team1: "0", team2: "0"} },
  { id: 'q3', round: 'QUARTERS', matchNumber: 3, status: 'UPCOMING', startTime: 'Sat - 01:00 PM', court: 'Side Court 1', sets: [{team1:0, team2:0}, {team1:0, team2:0}, {team1:0, team2:0}], currentSet: 0, currentPoints: {team1: "0", team2: "0"} },
  { id: 'q4', round: 'QUARTERS', matchNumber: 4, status: 'UPCOMING', startTime: 'Sat - 02:30 PM', court: 'Side Court 1', sets: [{team1:0, team2:0}, {team1:0, team2:0}, {team1:0, team2:0}], currentSet: 0, currentPoints: {team1: "0", team2: "0"} },
  // Semi Finals
  { id: 's1', round: 'SEMIS', matchNumber: 1, status: 'UPCOMING', startTime: 'Sun - 10:00 AM', court: 'Grand Stand', sets: [{team1:0, team2:0}, {team1:0, team2:0}, {team1:0, team2:0}], currentSet: 0, currentPoints: {team1: "0", team2: "0"} },
  { id: 's2', round: 'SEMIS', matchNumber: 2, status: 'UPCOMING', startTime: 'Sun - 12:00 PM', court: 'Grand Stand', sets: [{team1:0, team2:0}, {team1:0, team2:0}, {team1:0, team2:0}], currentSet: 0, currentPoints: {team1: "0", team2: "0"} },
  // Finals
  { id: 'f1', round: 'FINALS', matchNumber: 1, status: 'UPCOMING', startTime: 'Sun - 04:00 PM', court: 'Center Court', sets: [{team1:0, team2:0}, {team1:0, team2:0}, {team1:0, team2:0}], currentSet: 0, currentPoints: {team1: "0", team2: "0"} },
];

export const POINT_VALUES = ["0", "15", "30", "40", "AD"];
export const TIEBREAK_LIMIT = 7;
