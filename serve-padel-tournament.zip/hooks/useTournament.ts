
import { useState, useEffect, useCallback } from 'react';
import { Team, Match, TournamentState, MatchStatus } from '../types';
import { INITIAL_MATCHES, POINT_VALUES } from '../constants';

export function useTournament() {
  const [state, setState] = useState<TournamentState>(() => {
    const saved = localStorage.getItem('serve_padel_v2');
    if (saved) return JSON.parse(saved);
    return {
      teams: [],
      matches: INITIAL_MATCHES,
    };
  });

  useEffect(() => {
    localStorage.setItem('serve_padel_v2', JSON.stringify(state));
  }, [state]);

  const registerTeam = useCallback((team: Team) => {
    setState(prev => {
      if (prev.teams.length >= 8) return prev;
      const newTeams = [...prev.teams, team];
      const newMatches = [...prev.matches];
      
      const teamIndex = newTeams.length - 1;
      const matchIndex = Math.floor(teamIndex / 2);
      if (matchIndex < 4) {
        if (teamIndex % 2 === 0) {
          newMatches[matchIndex].team1Id = team.id;
        } else {
          newMatches[matchIndex].team2Id = team.id;
        }
      }

      return { ...prev, teams: newTeams, matches: newMatches };
    });
  }, []);

  const updateMatchScore = useCallback((matchId: string, teamNum: 1 | 2, playerId?: string) => {
    setState(prev => {
      const teams = [...prev.teams];
      const newMatches = prev.matches.map(m => {
        if (m.id !== matchId) return m;
        const newM = { ...m };
        
        // Attribution to player points
        if (playerId) {
          const teamId = teamNum === 1 ? newM.team1Id : newM.team2Id;
          const team = teams.find(t => t.id === teamId);
          if (team) {
            const player = team.players.find(p => p.id === playerId);
            if (player) player.pointsScored += 1;
          }
        }

        const current = teamNum === 1 ? newM.currentPoints.team1 : newM.currentPoints.team2;
        const other = teamNum === 1 ? newM.currentPoints.team2 : newM.currentPoints.team1;
        
        // Handle Tiebreak (6-6 in set)
        const inTiebreak = newM.sets[newM.currentSet].team1 === 6 && newM.sets[newM.currentSet].team2 === 6;
        
        if (inTiebreak) {
          const score = parseInt(current);
          const otherScore = parseInt(other);
          const nextScore = isNaN(score) ? 1 : score + 1;
          
          if (teamNum === 1) newM.currentPoints.team1 = nextScore.toString();
          else newM.currentPoints.team2 = nextScore.toString();
          
          if (nextScore >= 7 && (nextScore - otherScore >= 2)) {
             return handleGameWin(newM, teamNum, true);
          }
        } else {
          // Regular Padel scoring
          const idx = POINT_VALUES.indexOf(current);
          if (current === "40" && other !== "40" && other !== "AD") {
            return handleGameWin(newM, teamNum);
          } else if (current === "40" && other === "40") {
             if (teamNum === 1) newM.currentPoints.team1 = "AD";
             else newM.currentPoints.team2 = "AD";
          } else if (current === "40" && other === "AD") {
             newM.currentPoints.team1 = "40";
             newM.currentPoints.team2 = "40";
          } else if (current === "AD") {
             return handleGameWin(newM, teamNum);
          } else {
            if (teamNum === 1) newM.currentPoints.team1 = POINT_VALUES[idx + 1];
            else newM.currentPoints.team2 = POINT_VALUES[idx + 1];
          }
        }
        return newM;
      });
      return { ...prev, matches: newMatches, teams };
    });
  }, []);

  const handleGameWin = (match: Match, winnerNum: 1 | 2, tiebreak = false) => {
    const updated = { ...match };
    updated.currentPoints = { team1: "0", team2: "0" };
    const curSetIdx = updated.currentSet;
    if (winnerNum === 1) updated.sets[curSetIdx].team1 += 1;
    else updated.sets[curSetIdx].team2 += 1;

    const s1 = updated.sets[curSetIdx].team1;
    const s2 = updated.sets[curSetIdx].team2;
    
    // Set completed check
    let setOver = false;
    if (tiebreak) setOver = true;
    else if ((s1 >= 6 || s2 >= 6) && Math.abs(s1 - s2) >= 2) setOver = true;
    else if (s1 === 7 || s2 === 7) setOver = true;

    if (setOver) {
      if (updated.currentSet < 2) {
         const setsWon1 = updated.sets.filter(s => s.team1 > s.team2).length;
         const setsWon2 = updated.sets.filter(s => s.team2 > s.team1).length;
         if (setsWon1 === 2 || setsWon2 === 2) {
            updated.status = 'COMPLETED';
            updated.winnerId = setsWon1 === 2 ? updated.team1Id : updated.team2Id;
         } else {
            updated.currentSet += 1;
         }
      } else {
        updated.status = 'COMPLETED';
        updated.winnerId = s1 > s2 ? updated.team1Id : updated.team2Id;
      }
    }
    return updated;
  };

  const setMatchStatus = useCallback((matchId: string, status: MatchStatus) => {
    setState(prev => ({
      ...prev,
      matches: prev.matches.map(m => m.id === matchId ? { ...m, status } : m)
    }));
  }, []);

  const advanceWinner = useCallback((matchId: string, winnerId: string) => {
     setState(prev => {
        const matches = [...prev.matches];
        const match = matches.find(m => m.id === matchId);
        if (!match) return prev;

        match.status = 'COMPLETED';
        match.winnerId = winnerId;

        // Stats update for team
        const teams = prev.teams.map(t => {
           if (t.id === match.team1Id || t.id === match.team2Id) {
             const isWinner = t.id === winnerId;
             const setsWon = match.sets.filter(s => (t.id === match.team1Id ? s.team1 > s.team2 : s.team2 > s.team1)).length;
             const gamesWon = match.sets.reduce((acc, s) => acc + (t.id === match.team1Id ? s.team1 : s.team2), 0);
             return {
               ...t,
               stats: {
                 matchesPlayed: t.stats.matchesPlayed + 1,
                 setsWon: t.stats.setsWon + setsWon,
                 gamesWon: t.stats.gamesWon + gamesWon
               }
             };
           }
           return t;
        });

        // Bracket progression
        if (match.round === 'QUARTERS') {
           const targetSemiId = match.matchNumber <= 2 ? 's1' : 's2';
           const semi = matches.find(m => m.id === targetSemiId);
           if (semi) {
              if (match.matchNumber % 2 !== 0) semi.team1Id = winnerId;
              else semi.team2Id = winnerId;
           }
        } else if (match.round === 'SEMIS') {
           const final = matches.find(m => m.id === 'f1');
           if (final) {
              if (match.matchNumber === 1) final.team1Id = winnerId;
              else final.team2Id = winnerId;
           }
        }
        return { ...prev, matches, teams };
     });
  }, []);

  return { state, registerTeam, updateMatchScore, setMatchStatus, advanceWinner };
}
